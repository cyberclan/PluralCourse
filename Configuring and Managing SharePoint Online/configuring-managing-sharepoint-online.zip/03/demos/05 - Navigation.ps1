﻿Add-PnPNavigationNode `
	-Location TopNavigationBar `
	-Title "HR" `
	-Url https://globomanticsorg.sharepoint.com/sites/HR