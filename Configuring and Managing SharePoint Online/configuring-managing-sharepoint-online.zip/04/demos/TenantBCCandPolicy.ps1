﻿Set-SPOTenant `
	-BccExternalSharingInvitations $true `
	-BccExternalSharingInvitationsList vlad@globomantics.org `
	-CustomizedExternalSharingServiceUrl https://www.globomantics.org/sharingpolicies 