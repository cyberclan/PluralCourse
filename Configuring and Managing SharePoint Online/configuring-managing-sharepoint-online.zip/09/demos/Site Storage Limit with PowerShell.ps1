﻿Set-SPOSite `
    -Identity https://globomanticsorg.sharepoint.com/sites/CharityatGlobomantics `
    -StorageQuota 51200 `
    -StorageQuotaWarningLevel 49152
