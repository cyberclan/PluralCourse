﻿$site = Get-SPOSite https://globomanticsorg.sharepoint.com/sites/TestPSCommSite
Add-SPOSiteCollectionAppCatalog -Site $site